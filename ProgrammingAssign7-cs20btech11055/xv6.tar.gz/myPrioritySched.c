#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char *argv[]) {
  int pid;
  int k, n;
  int x, z;
  cps();
  setpriority(atoi(argv[1]));
  // printf(1,"The Priority is changed again\n");
  cps();
  exit();
}