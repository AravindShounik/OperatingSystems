#include "types.h"
#include "stat.h"
#include "user.h"

int arrGlobal[10000];

int main(void) 
{
    for(int i = 0;i<1000;i++)
    {
        arrGlobal[i]=i;
    }
    // int arrLocal[10000];
    pgtprint();
    exit();
} 